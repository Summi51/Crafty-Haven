import React from 'react'

const DrawingBlog = () => {
  return (
    <div>
      Drawing Blog
    </div>
  )
}

export default DrawingBlog
